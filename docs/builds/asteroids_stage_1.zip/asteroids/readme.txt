Asteroids was created by Tyre Bytes LLC  (www.tyrebytes.com)


Credits / Assets:
-------------------------------------------

https://screamingbrainstudios.itch.io/seamless-space-backgrounds
space_blue_nebula_06 by Screaming Brain Studios
space_blue_nebula_08 by Screaming Brain Studios

https://opengameart.org/content/assets-free-laser-bullets-pack-2020
laser_sprites by Wenrexa

If you have issues running on Windows you may need to install the following:

OpenAL:  http://openal.org/downloads/oalinst.zip
